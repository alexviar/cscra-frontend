import watchRegisterUser, {registerUser} from './registerUser'

export { registerUser }

export default watchRegisterUser

