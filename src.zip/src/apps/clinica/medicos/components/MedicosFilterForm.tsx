import React from "react"
import { Filter } from "../services"

type Props = {
  onFilter: (filter: Filter) => void
}

export const MedicosFilterForm = (props: Props)=>{
  return null
}