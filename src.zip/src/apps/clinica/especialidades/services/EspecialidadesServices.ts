import axios from "axios"
import apiClient from "../../../../commons/services/apiClient"
import { Page } from "../../../../commons/services/Page"

export type Especialidad = {
  id: number,
  nombre: string,
}
export const EspecialidadesService = {
  buscar: (page: Page, filter: string) => {
    const CancelToken = axios.CancelToken;
    const source = CancelToken.source()
  
    const promise = apiClient.get<{
      meta: {
        total: number
      },
      records: Especialidad[]
    }>("/especialidades", {
      params: {
        filter: {
          nombre: filter || undefined
        },
        page
      }
    })
    //@ts-ignore
    promise.cancel = () => {
      source.cancel('Query was cancelled by React Query')
    }
    return promise
  },
  importar: (archivo: File, separador: string, formato: string) =>{
    const formData = new FormData()
    formData.append("archivo", archivo, archivo.name)
    formData.append("separador", separador)
    formData.append("formato", formato)
    return apiClient.post("/especialidades/importar", formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    })
  }
}