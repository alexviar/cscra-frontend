import React from "react"
import { ListaMoraFilter as Filter } from "../services"

type Props = {
  onApply: (filter: Filter) => void
}

export default (props: Props)=>{
  return null
}