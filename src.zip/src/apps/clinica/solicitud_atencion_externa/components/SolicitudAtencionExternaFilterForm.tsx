import React from "react"
import { SolicitudesAtencionExternaFilter } from "../services/SolicitudesAtencionExternaService"

type Props = {
  onFilter: (filter: SolicitudesAtencionExternaFilter)=>void
}
export const SolicitudAtencionExternaFilterForm = (props: Props)=>{
  return null
}