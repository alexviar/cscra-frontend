export type Page = {
  current: number,
  size: number
}